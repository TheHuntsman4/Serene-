## Blog application using Django framework

visit- http://rajat7570.pythonanywhere.com to view the blog site
